import java.util.*;

class Main {

public static void delay(int ms) {
  if (1 == 1) { //set to != if you want to skip on all delays
  
    try {
      Thread.sleep(ms);
    }
    catch (InterruptedException ie) {
      Thread.currentThread().interrupt();
    }
} 
}

public static void main(String[] args) {
  String in = "";
  int highscoreEasy = 0;
  int highscoreMed = 0;
  int highscoreHard = 0;
  int highscoreExtreme = 0;
  int scoreTrack = 0;
  boolean tryAgain = true;
  boolean playAgain = true;

  Scanner scan = new Scanner(System.in);

  System.out.println("\nWelcome to the chicken game. The rules are simple, don't let your chicken die."); delay(2000);

  while (tryAgain) {
    System.out.println("\nEnter your difficulty (Easy, Medium, Hard, Extreme):");
    in = scan.nextLine();
  in = in.toLowerCase();

if (in.equals("easy")) {
  Easy easy = new Easy();
  scoreTrack = easy.run(highscoreEasy);
  System.out.println("\nFINAL SCORE: " + scoreTrack); delay(1000);
  if (scoreTrack > highscoreEasy) {
    System.out.println("\nNew easy high score!"); delay(1000);
    highscoreEasy = scoreTrack;
  }
  tryAgain = false;
}
else if (in.equals("medium")) {
Medium med = new Medium();
scoreTrack = med.run(highscoreMed);
System.out.println("\nFINAL SCORE: " + scoreTrack); delay(1000);
  if (scoreTrack > highscoreMed) {
    System.out.println("\nNew medium high score!"); delay(1000);
    highscoreMed = scoreTrack;
  }
tryAgain = false;
}
else if (in.equals("hard")) {
Hard hard = new Hard();
scoreTrack = hard.run(highscoreHard);
System.out.println("\nFINAL SCORE: " + scoreTrack); delay(1000);
  if (scoreTrack > highscoreHard) {
    System.out.println("\nNew hard high score!"); delay(1000);
    highscoreHard = scoreTrack;
  }
tryAgain = false;
}
else if (in.equals("extreme")) {
Extreme extreme = new Extreme();
scoreTrack = extreme.run(highscoreExtreme);
System.out.println("\nFINAL SCORE: " + scoreTrack); delay(1000);
  if (scoreTrack > highscoreExtreme) {
    System.out.println("\nNew extreme high score!"); delay(1000);
    highscoreExtreme = scoreTrack;
  }
tryAgain = false;
}
else {
  System.out.println("\nIncorrect input, please try again."); delay(1000);
  
  tryAgain = true;
}
  }

  while (playAgain) {
    tryAgain = true;
delay(4000);
for (int i = 0; i <= 100; i++) {
  System.out.println();
}
  System.out.println("\n____High_Scores____");
  System.out.println("Easy high score: " + highscoreEasy);
  System.out.println("Medium high score: " + highscoreMed);
  System.out.println("Hard high score: " + highscoreHard);
  System.out.println("Extreme high score: " + highscoreExtreme); delay(2000);
  System.out.println("\nWould you like to play again? (yes/no)");
  in = scan.nextLine();
  in = in.toLowerCase();
  if (in.equals("no")) {
    System.out.println("\nHope to see you again soon!");
playAgain = false;
  }

  else {

    while (tryAgain) {
    System.out.println("\nEnter your difficulty (Easy, Medium, Hard, Extreme):");
    in = scan.nextLine();
  in = in.toLowerCase();

if (in.equals("easy")) {
  Easy easy = new Easy();
  scoreTrack = easy.run(highscoreEasy);
  System.out.println("\nFINAL SCORE: " + scoreTrack); delay(1000);
  if (scoreTrack > highscoreEasy) {
    System.out.println("\nNew easy high score!"); delay(2000);
    highscoreEasy = scoreTrack;
  }
  tryAgain = false;
}
else if (in.equals("medium")) {
Medium med = new Medium();
scoreTrack = med.run(highscoreMed);
System.out.println("\nFINAL SCORE: " + scoreTrack); delay(1000);
  if (scoreTrack > highscoreMed) {
    System.out.println("\nNew medium high score!"); delay(2000);
    highscoreMed = scoreTrack;
  }
tryAgain = false;
}
else if (in.equals("hard")) {
Hard hard = new Hard();
scoreTrack = hard.run(highscoreHard);
System.out.println("\nFINAL SCORE: " + scoreTrack); delay(1000);
  if (scoreTrack > highscoreHard) {
    System.out.println("\nNew hard high score!"); delay(2000);
    highscoreHard = scoreTrack;
  }
tryAgain = false;
}
else if (in.equals("extreme")) {
Extreme extreme = new Extreme();
scoreTrack = extreme.run(highscoreExtreme);
System.out.println("\nFINAL SCORE: " + scoreTrack); delay(1000);
  if (scoreTrack > highscoreExtreme) {
    System.out.println("\nNew extreme high score!"); delay(2000);
    highscoreExtreme = scoreTrack;
  }
tryAgain = false;
}
else {
  System.out.println("\nIncorrect input, please try again."); delay(1000);
  tryAgain = true;
}
  }

  }
  }

}
}