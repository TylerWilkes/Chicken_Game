import java.util.*;

public class Hard {
  
public static void delay(int ms, int score) {
  if (1 == 1) { //set to != if you want to skip on all delays
  if (score >= 5) {
    ms = ms/2;
  }
    try {
      Thread.sleep(ms);
    }
    catch (InterruptedException ie) {
      Thread.currentThread().interrupt();
    }
}
}

public static boolean stats(int w, int f, int s, int h) {
  System.out.println("\n___Stats___");
  System.out.println("Water: " + w);
  System.out.println("Food: " + f);
  System.out.println("Sickness: " + s);
  System.out.println("Happiness: " + h);

  if(w <= 0) {
    System.out.println("\nYour chicken died of thirst.");
    return true;
  }
  else if(w > 100) {
    System.out.println("\nYour chicken drank too much water and died.");
    return true;
  }
  else if(f <= 0) {
    System.out.println("\nYour chicken starved to death.");
    return true;
  }
  else if(f > 100) {
    System.out.println("\nYour chicken ate too much food and died.");
    return true;
  }
  else if(s >= 100) {
    System.out.println("\nYour chicken died of a disease.");
    return true;
  }
  else if(s < 0) {
    System.out.println("\nYour chicken took medicine it didn't need and died.");
    return true;
  }
  else if(h <= 0) {
    System.out.println("\nYour chicken died of sadness.");
    return true;
  }
  else if(h > 100) {
    System.out.println("\nYour chicken got too excited and died.");
    return true;
  }
  else {
    return false;
  }
}



  public int run(int test) {

    Scanner reader = new Scanner(System.in);

    int food = 75;
    int water = 75;
    int sickness = 0;
    int happiness = 75;
    int random;
    int score = 0;
    int sickness1Count = 0;
    int sickness2Count = 0;
    int sickness3Count = 0;
    int sickness4Count = 0;
    int sickness5Count = 0;
    int sickness6Count = 0;
    boolean sickness1 = false;
    boolean sickness2 = false;
    boolean sickness3 = false;
    boolean sickness4 = false;
    boolean sickness5 = false;
    boolean sickness6 = false;
    boolean again = true;
    String name;
    String input;
    
    for (int i = 0; i <= 100; i++) {
      System.out.println();
    }

    System.out.println("\nWelcome to the hard difficulty chicken game."); delay(2000, score);
    System.out.println("\nWhat would you like to name your chicken?"); 
    name = reader.nextLine();
    System.out.println("\n" + name + " it is then..."); delay(2000, score);
    if (test == 0) {
    System.out.println("\nYour stats bar will look like this: "); delay(2000, score);
    if (stats(water, food, sickness, happiness)) {
      return score;
    } delay(3000, score);
    System.out.println("\nEach time a turn passes, your chicken will lose 5 food, 5 water, and 5 happiness:"); delay(5000, score);
    System.out.println("\nOn top of that, something random will happen to your chicken."); delay(4000, score);
    System.out.println("\nEach time a turn passes, you will get a chance to do something for your chicken too."); delay(4000, score);
    System.out.println("\nHere's what you can do:"); delay(1000, score);
    System.out.println("Eat = +15 food and +5 happiness");
    System.out.println("Drink = +10 water");
    System.out.println("Medicine = -10 sickness");
    System.out.println("Play = +20 happiness");
    System.out.println("Nothing = nothing"); delay(4000, score);
    System.out.println("\nJust type in the word and the action will be done."); delay(3000, score);
    System.out.println("\nDon't let food, water or happiness hit 0, or go above 100."); delay(2000, score);
    System.out.println("\nMake sure sickness doesn't hit 100 or drop below 0."); delay(3000, score);
    System.out.println("\nIn hard mode, a sickness last for 5 turns starting after your chicken gets it."); delay(3000, score);
    System.out.println("\nPRESS ENTER TO CONTINUE:");
    input = reader.nextLine();
    }
    else {
      System.out.println("\nThe tutorial will be skipped because you have played this difficulty before."); delay(3000, score);
    }
    
    for(int i = 0; i < 101; i++) {
    System.out.println();
    }

while(true) {

  if (score == 5) {
    System.out.println("\nTEXT WILL NOW FLOW 2x FASTER.");
    }

  if (sickness1) {
    if (stats(water, food, sickness, happiness)) {
      return score;
    } delay(3000, score);
    sickness1Count++;
    System.out.println("\nUnknown sickness 1 caused +5 sickness, and -5 happiness. Day " + sickness1Count + "/5."); delay(3000, score);
    sickness += 5;
    happiness -= 5;
    if (sickness1Count == 5) {
      System.out.println("\n" + name + " got over unknown sickness 1."); delay(3000, score);
      sickness1Count = 0;
      sickness1 = false;
    }
  }
  if (sickness2) {
    if (stats(water, food, sickness, happiness)) {
      return score;
    } delay(3000, score);
    sickness2Count++;
    System.out.println("\nUnknown sickness 2 caused +5 sickness, -5 water, and -5 happiness. Day " + sickness2Count + "/5."); delay(3000, score);
    sickness += 5;
    water -=5;
    happiness -= 5;
    if (sickness2Count == 5) {
      System.out.println("\n" + name + " got over unknown sickness 2."); delay(3000, score);
      sickness2Count = 0;
      sickness2 = false;
    }
  }
  if (sickness3) {
    if (stats(water, food, sickness, happiness)) {
      return score;
    } delay(3000, score);
    sickness3Count++;
    System.out.println("\nUnknown sickness 3 caused +10 sickness, -5 water, and -5 happiness. Day " + sickness3Count + "/5."); delay(3000, score);
    sickness += 10;
    water -=5;
    happiness -= 5;
    if (sickness3Count == 5) {
      System.out.println("\n" + name + " got over unknown sickness 3."); delay(3000, score);
      sickness3Count = 0;
      sickness3 = false;
    }
  }
  if (sickness4) {
    if (stats(water, food, sickness, happiness)) {
      return score;
    } delay(3000, score);
    sickness4Count++;
    System.out.println("\nUnknown sickness 4 caused +15 sickness, -5 water, and -5 happiness. Day " + sickness4Count + "/5."); delay(3000, score);
    sickness += 15;
    water -= 5;
    happiness -= 5;
    if (sickness4Count == 5) {
      System.out.println("\n" + name + " got over unknown sickness 4."); delay(3000, score);
      sickness4Count = 0;
      sickness4 = false;
    }
  }
  if (sickness5) {
    if (stats(water, food, sickness, happiness)) {
      return score;
    } delay(3000, score);
    sickness5Count++;
    System.out.println("\nUnknown sickness 5 caused +15 sickness, -5 water, -5 food, and -5 happiness. Day " + sickness5Count + "/5."); delay(3000, score);
    sickness += 15;
    water -= 5;
    food -= 5;
    happiness -= 5;
    if (sickness5Count == 5) {
      System.out.println("\n" + name + " got over unknown sickness 5."); delay(3000, score);
      sickness5Count = 0;
      sickness5 = false;
    }
  }
  if (sickness6) {
    if (stats(water, food, sickness, happiness)) {
      return score;
    } delay(3000, score);
    sickness6Count++;
    System.out.println("\nUnknown sickness 6 caused +15 sickness, -10 water, -5 food, and -5 happiness. Day " + sickness6Count + "/5."); delay(3000, score);
    sickness += 15;
    water -= 10;
    food -= 5;
    happiness -= 5;
    if (sickness6Count == 5) {
      System.out.println("\n" + name + " got over unknown sickness 6."); delay(3000, score);
      sickness6Count = 0;
      sickness6 = false;
    }
  }
    
    
    
  if (score != 0) {
    if (stats(water, food, sickness, happiness)) {
      return score;
    } delay(3000, score);
water -= 5;
food -= 5;
happiness -=5;
System.out.println("\nDaily consumption, -5 water, food, and happiness."); delay(2000, score);
if (stats(water, food, sickness, happiness)) {
  return score;
} delay(3000, score);

System.out.println();

  random = (int)(Math.random()*32);

  if (score == 1) {
    random = 1;
  }

  switch (random) {
    case 0:
    System.out.println(name + " layed an egg, -5 food."); delay(3000, score);
    food -= 5;
    break;

    case 1:
    System.out.println("Dry air today, -5 water."); delay(3000, score);
    water -= 5;
    break;
 
    case 2:
    System.out.println(name + " had a bad day, -15 happiness."); delay(3000, score);
    happiness -= 15;
    break;
 
    case 3:
    if (((int)(Math.random()*50)) == 0) {
      System.out.println(name + " stepped on a lego and died.");
        return score;
    }
    else {
    System.out.println("Nothing extra special happened today."); delay(3000, score);
    }
    break;
  
    case 4:
    System.out.println("You have extra free time today, +1 turn."); delay(3000, score);
    again = true;
  while(again) {
    System.out.println("\nCommands:"); delay(1000, score);
  System.out.println("eat = +15 food and +5 happiness");
  System.out.println("drink = +10 water");
  System.out.println("medicine = -10 sickness");
  System.out.println("play = +20 happiness");
  System.out.println("nothing = nothing");
  System.out.println("\nWhat would you like to do?");
  input = reader.nextLine();
  input = input.toLowerCase();
  again = false;
  if (input.equals("drink")) {
    water += 10;
  }
  else if (input.equals("eat")) {
    food += 15;
    happiness += 5;
  }
  else if (input.equals("medicine")) {
    sickness -= 10;
  }
  else if (input.equals("play")) {
    happiness += 20;
  }
  else if (input.equals("nothing")) {
  }
  else {
    again = true;
    System.out.println("\nNot a valid command, try again.");
  }
  }
    break;
 
    case 5:
    System.out.println(name + " had a great day, +15 happiness."); delay(3000, score);
    happiness += 15;
    break;
 
    case 6:
    System.out.println(name + " found some bugs, +10 food."); delay(3000, score);
    food += 10;
    break;
 
    case 7:
    System.out.println("It rained today and your chicken dranks some, +10 water."); delay(3000, score);
    water += 10;
    break;
 
    case 8:
    System.out.println(name + " went on a run, -10 food and -15 water."); delay(3000, score);
    food -= 10;
    water -= 15;
    break;
 
    case 9:
    System.out.println(name + " just now realized it was hungry, -10 food."); delay(3000, score);
    food -= 10;
    break;
 
    case 10:
    System.out.println(name + " wanted to check in on your OCD, -1 everything (except sickness)."); delay(3000, score);
    food -= 1;
    water -= 1;
    happiness -= 1;
    break;
 
    case 11:
    System.out.println(name + " tried to eat dry wood, -10 water."); delay(3000, score);
    water -= 10;
    break;
 
    case 12:
    System.out.println(name + "\'s best friend got slaughtered, -20 happiness."); delay(3000, score);
    happiness -= 20;
    break;
 
    case 13:
    System.out.println(name + " got unknown sickness 1."); delay(3000, score);
    sickness1 = true;
    sickness1Count = 0;
    break;
 
    case 14:
    System.out.println(name + " got unknown sickness 2."); delay(3000, score);
    sickness2 = true;
    sickness2Count = 0;
    break;
 
    case 15:
    System.out.println(name + " got unknown sickness 3."); delay(3000, score);
    sickness3 = true;
    sickness3Count = 0;
    break;
 
    case 16:
    System.out.println(name + " got unknown sickness 4."); delay(3000, score);
    sickness4 = true;
    sickness4Count = 0;
    break;
 
    case 17:
    System.out.println(name + " got unknown sickness 5."); delay(3000, score);
    sickness5 = true;
    sickness5Count = 0;
    break;

    case 18:
    System.out.println(name + " got unknown sickness 6."); delay(3000, score);
    sickness6 = true;
    sickness6Count = 0;
    break;

    case 19:
    System.out.println(name + " layed an egg, -5 food."); delay(3000, score);
    food -= 5;
    break;

    case 20:
    System.out.println("Dry air today, -5 water."); delay(3000, score);
    water -= 5;
    break;
 
    case 21:
    System.out.println(name + " had a bad day, -15 happiness."); delay(3000, score);
    happiness -= 15;
    break;
 
    case 22:
    if (((int)(Math.random()*50)) == 0) {
      System.out.println(name + " stepped on a lego and died.");
        return score;
    }
    else {
    System.out.println("Nothing extra special happened today."); delay(3000, score);
    }
    break;
  
    case 23:
    System.out.println("You have extra free time today, +1 turn."); delay(3000, score);
    again = true;
  while(again) {
    System.out.println("\nCommands:"); delay(1000, score);
  System.out.println("eat = +15 food and +5 happiness");
  System.out.println("drink = +10 water");
  System.out.println("medicine = -10 sickness");
  System.out.println("play = +20 happiness");
  System.out.println("nothing = nothing");
  System.out.println("\nWhat would you like to do?");
  input = reader.nextLine();
  input = input.toLowerCase();
  again = false;
  if (input.equals("drink")) {
    water += 10;
  }
  else if (input.equals("eat")) {
    food += 15;
    happiness +=5;
  }
  else if (input.equals("medicine")) {
    sickness -= 10;
  }
  else if (input.equals("play")) {
    happiness += 20;
  }
  else if (input.equals("nothing")) {
  }
  else {
    again = true;
    System.out.println("\nNot a valid command, try again.");
  }
  }
    break;
 
    case 24:
    System.out.println(name + " had a great day, +15 happiness."); delay(3000, score);
    happiness += 15;
    break;
 
    case 25:
    System.out.println(name + " found some bugs, +10 food."); delay(3000, score);
    food += 10;
    break;
 
    case 26:
    System.out.println("It rained today and your chicken dranks some, +10 water."); delay(3000, score);
    water += 10;
    break;
 
    case 27:
    System.out.println(name + " went on a run, -10 food and -15 water."); delay(3000, score);
    food -= 10;
    water -= 15;
    break;
 
    case 28:
    System.out.println(name + " just now realized it was hungry, -10 food."); delay(3000, score);
    food -= 10;
    break;
 
    case 29:
    System.out.println(name + " wanted to check in on your OCD, -1 everything (except sickness)."); delay(3000, score);
    food -= 1;
    water -= 1;
    happiness -= 1;
    break;
 
    case 30:
    System.out.println(name + " tried to eat dry wood, -10 water."); delay(3000, score);
    water -= 10;
    break;
 
    case 31:
    System.out.println(name + "\'s best friend got slaughtered, -20 happiness."); delay(3000, score);
    happiness -= 20;
    break;
    
  }
  if (stats(water, food, sickness, happiness)) {
    return score;
  } delay(2000, score);
  System.out.println("\nPRESS ENTER TO CONTINUE:");
  input = reader.nextLine();
  for(int i = 0; i < 101; i++) {
    System.out.println();
    }
  
}

again = true;
System.out.println("\nSCORE: " + score);
System.out.println("\nYour turn:");
  while(again) {
    
    if (stats(water, food, sickness, happiness)) {
      return score;
    } delay(2000, score);
  System.out.println("\nCommands:"); delay(1000, score);
  System.out.println("eat = +15 food and +5 happiness");
  System.out.println("drink = +10 water");
  System.out.println("medicine = -10 sickness");
  System.out.println("play = +20 happiness");
  System.out.println("nothing = nothing");

  System.out.println("\nWhat would you like to do?");
  input = reader.nextLine();
  input = input.toLowerCase();
  again = false;
  if (input.equals("drink")) {
    water += 10;
  }
  else if (input.equals("eat")) {
    food += 15;
    happiness += 5;
  }
  else if (input.equals("medicine")) {
    sickness -= 10;
  }
  else if (input.equals("play")) {
    happiness += 20;
  }
  else if (input.equals("nothing")) {
  }
  else {
    again = true;
    System.out.println("\nNot a valid command, try again."); delay(2000, score);
  }
  }

for(int i = 0; i < 101; i++) {
    System.out.println();
    }

    score++;
    System.out.println("\nSCORE: " + score + "\n");

if (score < 10) {
    System.out.println("  _");
    System.out.println("<(')_");
    System.out.println("  (  )<");
    System.out.println("   ||");
System.out.println(name + "\'s activities:");
}
if (score >= 10 && score < 20) {
    System.out.println(" MM");
    System.out.println("<\' \\___/|");
    System.out.println(" \\_  __/");
    System.out.println("   ][");
  System.out.println(name + "\'s activities:");
  if (score == 10) {
      System.out.println("\n" + name + " got older.");
    }
}
if (score >= 20 && score < 30) {
    System.out.println(" __/");
    System.out.println("<\' \\____/|");
    System.out.println(" |\\__  _/");
    System.out.println(" |   ][");
  System.out.println(name + "\'s activities:");
  if (score == 20) {
      System.out.println("\n" + name + " got older.");
    }
}
if (score >= 30) {
    System.out.println("   \\  |  \\  |  /  |  /");
    System.out.println("  \\ \\  \\  \\ | /  /  /  /");
    System.out.println("   \\    MM            /");
    System.out.println("  \\ \\  <\' \\______/|  / /");
    System.out.println("   \\     \\_  __  /    /");
    System.out.println("           ][  ][");
  System.out.println(name + "\'s activities:");
  if (score == 30) {
      System.out.println("\n" + name + " got older.");
    }
}
  
}
  }
}